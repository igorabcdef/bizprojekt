import React from 'react';
import { Star, Clock, Shield, Truck } from 'lucide-react';

const products = [
  {
    id: 1,
    name: 'Classic Comfort',
    price: 49.99,
    description: 'Klasyczne sandały ze skóry naturalnej, idealne na co dzień'
  },
  {
    id: 2,
    name: 'Summer Elegance',
    price: 65.99,
    description: 'Eleganckie sandały z plecionymi paskami'
  },
  {
    id: 3,
    name: 'Premium Comfort Plus',
    price: 79.99,
    description: 'Luksusowe sandały z ergonomiczną podeszwą'
  }
];

const reviews = [
  {
    id: 1,
    name: 'Anna Kowalska',
    rating: 5,
    text: 'Najwygodniejsze sandały, jakie kiedykolwiek nosiłam!'
  },
  {
    id: 2,
    name: 'Piotr Nowak',
    rating: 5,
    text: 'Świetna jakość wykonania, warte swojej ceny.'
  },
  {
    id: 3,
    name: 'Maria Wiśniewska',
    rating: 4,
    text: 'Bardzo wygodne i stylowe, noszę je codziennie.'
  }
];

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <header className="bg-[#D4A373] text-white">
        <div className="container mx-auto px-4 py-16">
          <h1 className="text-5xl font-bold mb-4">Good Sandals</h1>
          <p className="text-xl">Tradycja, komfort i styl w każdym kroku</p>
        </div>
      </header>

      {/* Zalety */}
      <section className="py-16 bg-[#FEFAE0]">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-[#D4A373]">Dlaczego warto wybrać Good Sandals?</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <Shield className="w-12 h-12 mx-auto mb-4 text-[#D4A373]" />
              <h3 className="font-semibold mb-2">Najwyższa jakość</h3>
              <p>Wykonane z najlepszych materiałów</p>
            </div>
            <div className="text-center">
              <Clock className="w-12 h-12 mx-auto mb-4 text-[#D4A373]" />
              <h3 className="font-semibold mb-2">Trwałość</h3>
              <p>Gwarancja długiego użytkowania</p>
            </div>
            <div className="text-center">
              <Star className="w-12 h-12 mx-auto mb-4 text-[#D4A373]" />
              <h3 className="font-semibold mb-2">Komfort</h3>
              <p>Ergonomiczna konstrukcja</p>
            </div>
            <div className="text-center">
              <Truck className="w-12 h-12 mx-auto mb-4 text-[#D4A373]" />
              <h3 className="font-semibold mb-2">Szybka dostawa</h3>
              <p>Wysyłka w 24h</p>
            </div>
          </div>
        </div>
      </section>

      {/* Historia firmy */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-8 text-[#D4A373]">Nasza Historia</h2>
          <div className="max-w-3xl mx-auto text-center">
            <p className="mb-4">
              Od 1995 roku Good Sandals tworzy wyjątkowe obuwie, łącząc tradycyjne rzemiosło z nowoczesnymi technologiami.
              Nasza podróż rozpoczęła się od małego warsztatu w Krakowie, gdzie każda para sandałów była tworzona ręcznie.
            </p>
            <p>
              Dziś, po ponad 25 latach doświadczenia, nadal kierujemy się tą samą pasją do tworzenia najwyższej jakości
              obuwia, które łączy w sobie komfort, styl i trwałość.
            </p>
          </div>
        </div>
      </section>

      {/* Produkty */}
      <section className="py-16 bg-[#FEFAE0]">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-[#D4A373]">Nasze Produkty</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {products.map((product) => (
              <div key={product.id} className="bg-white rounded-lg shadow-lg overflow-hidden p-6">
                <h3 className="text-xl font-bold mb-2">{product.name}</h3>
                <p className="text-gray-600 mb-4">{product.description}</p>
                <p className="text-2xl font-bold text-[#D4A373]">{product.price} zł</p>
                <button className="mt-4 w-full bg-[#D4A373] text-white py-2 px-4 rounded hover:bg-[#B08968] transition-colors">
                  Dodaj do koszyka
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Opinie */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-[#D4A373]">Opinie Klientów</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {reviews.map((review) => (
              <div key={review.id} className="bg-[#FEFAE0] p-6 rounded-lg">
                <div className="flex mb-4">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-[#D4A373] fill-current" />
                  ))}
                </div>
                <p className="mb-4 italic">"{review.text}"</p>
                <p className="font-semibold">{review.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#D4A373] text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p>© 2024 Good Sandals. Wszystkie prawa zastrzeżone.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;